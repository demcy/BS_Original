﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain
{
    public class Game
    {
        public int GameId { get; set; }

        //public List<User> Users { get; set; } = new List<User>();
        public int UserId { get; set; }
        public User User { get; set; }
        
        [MaxLength(64)]
        public string GameName { get; set; }

        
    }
}