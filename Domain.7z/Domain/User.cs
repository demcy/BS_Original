using System.ComponentModel.DataAnnotations.Schema;

namespace Domain
{
    public class User
    {
        public int UserId { get; set; }
        
        public int BoardId { get; set; }
        public Board Board { get; set; }
        //public Board SelfBoard { get; set; }
        //public string UserName { get; set; }

        //[NotMapped]
        //public Board[] Boards { get; set; } = new Board[2];

       

        
    }
}