using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain
{
    public class Board
    {
        public int BoardId { get; set; }
        
        //public int RowNodeId { get; set; }

        public List<RowNode> RowNodes { get; set; } = new List<RowNode>();
        
        [MaxLength(64)]
        public string BoardName { get; set; } 
        
        //public Board(int boardId)
        //{
            //BoardId = boardId;
            //for (int i = 0; i < 10; i++)
            //{
                //RowNodes.Add(new RowNode());
            //}
        //}
    }
}